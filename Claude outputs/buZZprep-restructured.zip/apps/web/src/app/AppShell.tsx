import { BookOpen, CalendarDays, CircleUserRound, House, NotebookPen, WifiOff } from 'lucide-react';
import { NavLink, Outlet } from 'react-router';
import { Logo } from '@/components/Logo';
import { useMe } from '@/features/auth/api';
import { cn } from '@/lib/utils';
import { useNotificationLinks } from './hooks/useNotificationLinks';
import { useOnline } from './hooks/useOnline';

const NAV = [
  { to: '/', label: 'Home', icon: House, end: true },
  { to: '/schedule', label: 'Schedule', icon: CalendarDays },
  { to: '/learn', label: 'Learn', icon: BookOpen },
  { to: '/journal', label: 'Journal', icon: NotebookPen },
  { to: '/profile', label: 'Profile', icon: CircleUserRound },
] as const;

/** The signed-in layout: a sidebar on wide screens, a tab bar on phones. */
export function AppShell() {
  useNotificationLinks();
  const online = useOnline();
  const { data: me } = useMe();

  return (
    <div className="min-h-dvh md:grid md:grid-cols-[232px_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-dvh flex-col border-r bg-card/40 px-3 py-5 md:flex">
        <div className="mb-6 flex items-center gap-2.5 px-2">
          <Logo className="size-8 rounded-[9px]" />
          <span className="text-[17px] font-semibold tracking-[-0.01em]">buZZprep</span>
        </div>
        <nav className="grid gap-0.5" aria-label="Main">
          {NAV.map(({ to, label, icon: Icon, ...rest }) => (
            <NavLink
              key={to}
              to={to}
              end={'end' in rest}
              className={({ isActive }) =>
                cn(
                  'flex h-10 items-center gap-3 rounded-[10px] px-3 text-[15px] transition-colors',
                  isActive
                    ? 'bg-accent font-medium text-accent-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                )
              }
            >
              <Icon className="size-[18px]" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto grid gap-1 px-2 text-[13px] text-muted-foreground">
          {!online && (
            <span className="inline-flex items-center gap-1.5 text-warning">
              <WifiOff className="size-3.5" /> Offline — changes will sync
            </span>
          )}
          <span className="truncate">{me?.user.displayName}</span>
        </div>
      </aside>

      <main className="min-w-0 pb-[calc(76px+env(safe-area-inset-bottom))] md:pb-12">
        {!online && (
          <div className="sticky top-0 z-30 flex items-center justify-center gap-2 bg-warning/15 px-4 py-1.5 pt-[max(env(safe-area-inset-top),6px)] text-[13px] font-medium md:hidden">
            <WifiOff className="size-3.5" /> Offline — showing saved data
          </div>
        )}
        <Outlet />
      </main>

      <nav
        aria-label="Main"
        className="fixed inset-x-0 bottom-0 z-40 border-t bg-nav backdrop-blur-xl backdrop-saturate-150 safe-bottom md:hidden"
      >
        <div className="mx-auto grid h-[58px] max-w-lg grid-cols-5">
          {NAV.map(({ to, label, icon: Icon, ...rest }) => (
            <NavLink
              key={to}
              to={to}
              end={'end' in rest}
              className={({ isActive }) =>
                cn(
                  'flex flex-col items-center justify-center gap-[3px] text-[11px] font-medium transition-colors',
                  isActive ? 'text-primary' : 'text-muted-foreground',
                )
              }
            >
              {({ isActive }) => (
                <>
                  <Icon className="size-[23px]" strokeWidth={isActive ? 2.2 : 1.8} />
                  {label}
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
